package com.example.demo.repository;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Product;
@Transactional
@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {
	@Query("select p from Product p where p.name=:name")
	Product findproductbyname(String name);
	/*@Query("select p from Product p where p.rating<2")
	List<Product> deleteproducts();*/
}

